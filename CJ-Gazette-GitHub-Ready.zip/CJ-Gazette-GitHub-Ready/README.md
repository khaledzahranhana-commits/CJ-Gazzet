# CJ Gazette

Upload `index.html` and the `assets` folder to GitHub.

For GitHub Pages:
Settings > Pages > Branch: main > Folder: /root
